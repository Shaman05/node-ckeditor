/**
 * Created by ChenChao on 2017/3/16.
 */

var request = require('request');
var http = require('http');
var https = require('https');
var fs = require('fs');
var path = require('path');
var url = require('url');
var out = process.stdout;

function downloadFile(uri, callback){
    var pathname = url.parse(uri).pathname;
    var basename = path.basename(pathname);
    var saveFile = path.join(__dirname, 'download', basename);

    var totalSize = 0;
    var passedLength = 0;

    var pp = request.get(uri);
    console.log('尝试连接下载地址，请耐心等待片刻...');
    pp.on('error', function (err) {
        console.log('出错！');
        console.log(err);
    }).on('response', function (res) {
        if(res.statusCode !== 200){
            console.log('文件下载失败！原因：');
            console.log(res.statusCode, res.statusMessage);
        }else{
            totalSize = res.caseless.dict['content-length'];
            console.log('连接下载地址成功！获取文件大小：' + totalSize + ' bytes!，准备下载...');
            console.time('下载耗时');

            var req = http.request(uri, function (res) {
                var stream = fs.createWriteStream(saveFile, {
                    flags: 'w',
                    mode: 0o666,
                    autoClose: true
                });
                stream.on('open', function(){});
                stream.on('error', function(err){
                    console.log('\n保存文件出错：');
                    console.log(err);
                });
                stream.on('close', function(){
                    console.log('\n文件已保存至本地!');
                    console.timeEnd('下载耗时');
                    callback && callback(saveFile);
                });
                res.on('data', function (chunk) {
                    passedLength += chunk.length;
                    stream.write(chunk);

                    var percent = ((passedLength / totalSize) * 100).toFixed(2);
                    out.clearLine();
                    out.cursorTo(0);
                    out.write('接收数据中，已完成：' + passedLength + ' bytes, ' + percent + '%');
                });
                res.on('end', function() {
                    stream.end();
                });
            });
            req.on('error', function(e){
                console.log('请求出错：');
                console.log(e);
            });
            req.end();
        }
    });
}

//var fileUrl  = 'http://image.tianjimedia.com/uploadImages/2015/129/56/J63MI042Z4P8.jpg';
var fileUrl  = 'http://106.15.33.201/download/app.rar';
//var fileUrl  = 'http://yinyueshiting.baidu.com/data2/music/e7332484121d72179f4d5485afd4037c/540233604/2338221512968461128.mp3?xcode=9af5751e6e93e255180b9e6dd2675aac';

downloadFile(fileUrl, function(saveFile){
    console.log(`\n${saveFile} 下载完毕！`);
});

module.exports = downloadFile;